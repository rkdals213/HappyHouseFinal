<template>
    <div class="container">
        <h1>1인 가구를 위한 주택 검색 및 커뮤니티 게시판</h1>

        <h2>배경 : 자취할 주택을 찾을 때 주변 편의시설과 접근성이 좋은지를 확인할 필요성</h2>
        <img src="@/assets/intro3.jpg" />
        <p>출처: https://www.facebook.com/salrimarket/</p>
    </div>
</template>
