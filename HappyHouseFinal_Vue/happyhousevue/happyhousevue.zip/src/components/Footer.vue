<template>
    <div id="footer">
        <h3>Copyright by K2. All rights reserved.</h3>
    </div>
</template>

<script></script>

<style>
#footer {
    background-size: 8%;
    background-color: dimgray;
    /* background-color: aqua; */
    padding: 3%;
    height: 130px;
}
h3 {
    color: floralwhite;
}
</style>
