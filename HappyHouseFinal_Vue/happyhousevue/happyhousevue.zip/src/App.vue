<template>
  <div id="app">
    <Header />
    <hr />
    <div id="nav">
      <router-link to="/">About</router-link> | <router-link to="/houseinfo">주택 정보 / 편의시설 검색</router-link> | <router-link to="/housedeal">주택 매매 검색</router-link> |
      <router-link to="/boardlist/1/1">1인 가구 게시판</router-link>
    </div>
    <hr />
    <div>
      <router-view class="container" />
    </div>
    <hr />
    <Footer />
  </div>
</template>
<script>
import Header from "@/components/Header.vue";
import Footer from "@/components/Footer.vue";
export default {
  name: "App",
  components: {
    Header,
    Footer,
  },
};
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
